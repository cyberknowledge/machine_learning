%%% Mathlab Code for Linear Regression
% Dataset: Diabetes
% Load: Double-clic diabetes.mat

% Load Dataset and define X and Y
predNames = diabetes.Properties.VariableNames(1:end-1);
x = diabetes{:,1:end-1};
y = diabetes{:,end};

% Store the first 100 datapoints of BMI in x_bmi
x_bmi = x(1:100,3);

% Generate a scatter plot of the first 100 values
% BMI and Y features in diabetes dataset
% Set this plot in figure 1
figure(1);
scatter(x_bmi,y(1:100))
xlabel('x')
ylabel('y')

% Compute the Linear Regression of BMI with respect to Y
Bols_1 = x_bmi\y(1:100)

% Retain plots in figure 1 in the current axes so that new plots
% added to the axes do not delete existing plots.
hold on
% Plot the input data BMI and the predicted Y (BMI*Bols)
plot(x_bmi, x_bmi*Bols_1)
title({['Scatter Plot Data Features BMI and Y']
       ['Model Represented by the Mesh $$\hat{Y}$$']},'Interpreter','Latex','FontSize',18)
hold off

% Plot scatterplot of first 100 datapoints
% of BMI and BP features in Figure 2
figure(2);
% Set matrix with datapoints of BMI and BP features
% in variable x_bmi_bp
x_bmi_bp=x(1:100,3:4);
% Set vextorwith first 100 datapoints of BP 
% in separate variable
x_bp = x(1:100,4);
% Generate Scatter plot using Scatter3
scatter3(x_bmi,x_bp,y(1:100))
% Set figure labels
xlabel('BMI')
ylabel('y')

% Compute the Linear Regression of BMI and BP with respect to Y
Bols_2 = x_bmi_bp\y(1:100)
% Prediction using Bols_2
y_hat = x_bmi_bp*Bols_2;
% Retain plots in figure 1 in the current axes so that new plots
% added to the axes do not delete existing plots.
hold on

% Generate Mesh
F = TriScatteredInterp(x_bmi,x_bp,y_hat);
x_bmi_fit = min(x_bmi):0.25:max(x_bmi);
x_bp_fit = min(x_bp):0.25:max(x_bp);
[X1FIT,X2FIT] = meshgrid(x_bmi_fit,x_bp_fit);
YFIT = F(X1FIT,X2FIT);

% Plot scatter plot of x_bmi,x_bp,and y_hat
scatter3(x_bmi,x_bp,y_hat,40,"red","filled",'d');
hold on;

% Plot generated mesh with the set limitations
mesh(X1FIT,X2FIT,YFIT)

% Define labels
title({['Scatter Plot Data Features BMI, BP, and Y']
       ['Model Represented by the Mesh $$\hat{Y}$$']},'Interpreter','Latex','FontSize',18)
xlabel('BMI','fontweight','bold','fontsize',16)
ylabel('BP','fontweight','bold','fontsize',16)
zlabel('Y','fontweight','bold','fontsize',16)
view(150,50)
hold off
