%%% Mathlab Code for Linear Regression
% Dataset: Diabetes
% Load: Double-clic diabetes.mat
predNames = diabetes.Properties.VariableNames(1:end-1);
%x = diabetes{:,1:end-1};
%y = diabetes{:,end};

% Store each feature of interest in x,y,z variables
x=diabetes.BMI;
y=diabetes.BP;
z=diabetes.Y;  

% Set matrix with datapoints of BMI and BP features
% in variable x_bmi_bp
x_bmi_bp = diabetes{:,3:4};

% Compute the Linear Regression of BMI and BP with respect to Y
Bols = x_bmi_bp\z
%Bols = lasso(x_bmi_bp,z)

% Model's Prediction using Bols
z_hat = x_bmi_bp*Bols;

%%%%% FIGURE 1 %%%%%%
% Generate Mesh
F = TriScatteredInterp(x,y,z);
ti = 0:0.1:150;
[qx,qy] = meshgrid(ti,ti);
qz = F(qx,qy);

% Plot scatter plot of BMI, BP, and Y
figure(1);scatter3(x,y,z,25,"black","filled");
hold on;

% Plot generated Mesh
mesh(qx,qy,qz);
% Set Plot's Labels
title('Scatter Plot of Diabetes Dataset Features BMI, BP, and Y with Overfitted Mesh','Interpreter','Latex','FontSize',18)
xlabel('BMI','fontweight','bold','fontsize',16)
ylabel('BP','fontweight','bold','fontsize',16)
zlabel('Y','fontweight','bold','fontsize',16)
% Set figure's view angle
view(-15,15)
hold off;

%%%%% FIGURE 2 %%%%%%
% Generate Mesh
F = TriScatteredInterp(x,y,z_hat);
ti = 0:0.1:150;
[qx,qy] = meshgrid(ti,ti);
qz = F(qx,qy);

% Plot scatter plot of BMI, BP, and Y
figure(2);
scatter3(x,y,z,25,"black","filled");
hold on;
% Plot scatter plot of BMI, BP, and Y_hat (Model's Prediction)
scatter3(x,y,z_hat,40,"red","filled",'d');
hold on;
% Ignore plotting Generated Mesh
%mesh(qx,qy,qz);
% Set Plot's Labels
title('Scatter Plot of Y and the Model Predicted $$\hat{Y}$$','Interpreter','Latex','FontSize',18)
xlabel('BMI','fontweight','bold','fontsize',16)
ylabel('BP','fontweight','bold','fontsize',16)
zlabel('Y','fontweight','bold','fontsize',16)
% Set figure's view angle
view(-15,15)

%%%%% FIGURE 3 %%%%%%
% Generate Mesh
F = TriScatteredInterp(x,y,z_hat);
ti = 0:0.1:150;
[qx,qy] = meshgrid(ti,ti);
qz = F(qx,qy);

% Plot scatter plot of BMI, BP, and Y
figure(3);
scatter3(x,y,z,25,"black","filled");
hold on;
% Plot scatter plot of BMI, BP, and Y_hat (Model's Prediction)
scatter3(x,y,z_hat,40,"red","filled",'d');
hold on;
mesh(qx,qy,qz);
% Set Plot's Labels
title({['Scatter Plot Data Features BMI, BP, and Y']
       ['Model Represented by the Mesh $$\hat{Y}$$']},'Interpreter','Latex','FontSize',18)
xlabel('BMI','fontweight','bold','fontsize',16)
ylabel('BP','fontweight','bold','fontsize',16)
zlabel('Y','fontweight','bold','fontsize',16)
% Set figure's view angle
view(-15,15)

