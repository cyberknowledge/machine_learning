% Set the location of the diabetes dataset
filename = 'diabetes.txt'; urlwrite('http://www.stanford.edu/~hastie/Papers/LARS/diabetes.data',filename);

% Define data format
formatSpec = '%f%f%f%f%f%f%f%f%f%f%f%[^\n\r]';
% Open file in read mode
fileID = fopen(filename,'r');
% Define columns delimiters 
dataArray = textscan(fileID, formatSpec, 'Delimiter', '\t', 'HeaderLines' ,1, 'ReturnOnError', false);
% Close file
fclose(fileID);
% Set dataset column labels
diabetes = table(dataArray{1:end-1}, 'VariableNames', {'AGE','SEX','BMI','BP','S1','S2','S3','S4','S5','S6','Y'});
% Delete unwanted variables
clearvars filename delimiter startRow formatSpec fileID dataArray ans;

% Delete loaded text file
delete diabetes.txt

% Set labels in variable
predNames = diabetes.Properties.VariableNames(1:end-1);
% Set the dataset's input data in variable X
X = diabetes{:,1:end-1};
% Set the dataset labels in variable Y
y = diabetes{:,end};

% Test for linear independence
A = [1,1,1;1,2,3;4,4,4]
A = transpose(A)

